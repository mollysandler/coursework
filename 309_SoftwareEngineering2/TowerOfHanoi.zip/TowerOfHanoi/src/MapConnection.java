import javax.swing.*;
import java.awt.*;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

public class MapConnection extends JPanel {

    public void addMap() {
        setLayout(new GridLayout(1, 1));
        try {
            ImageIcon imageicon = getMap();
            imageicon.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH);
            add(new JLabel(imageicon));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private ImageIcon getMap() throws Exception {
        String apiKey = "AkuMBd-i_2KoqOK6r2rBGBwYT3YGGvJZUdzTv3ghpSI707tyWCI_LjtOxJS8FrUI";
        String location = "40.714728,-73.998672";
        String mapUrl = "https://dev.virtualearth.net/REST/v1/Imagery/Map/Road" + location + "?zoomLevel=10&mapSize=200,200&key=" + apiKey;

        URL mapImageUrl = new URL(mapUrl);
        URLConnection connection = mapImageUrl.openConnection();
        InputStream inputStream = connection.getInputStream();

        OutputStream outputStream = new FileOutputStream("image.jpg");
        byte[] b = new byte[2048];
        int length;
        while ((length = inputStream.read(b)) != -1){
            outputStream.write(b, 0, length);
        }
        inputStream.close();
        outputStream.close();
        return new ImageIcon("image.jpg");
    }
}
