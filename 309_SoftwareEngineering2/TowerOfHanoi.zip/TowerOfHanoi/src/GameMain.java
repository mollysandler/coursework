import javax.swing.*;
import java.awt.*;
import java.util.Map;


/**
 * The main class for the Towers of Hanoi game.
 * It extends creates a new TowerPanel object to display the game.
 * Define number of disks and window size.
 *
 * @author Professor
 */
public class GameMain extends JFrame {

  public GameMain() {

    setLayout( new FlowLayout() );
    JPanel lPanel = new JPanel();
    JPanel rPanel = new JPanel();
    lPanel.setPreferredSize( new Dimension( 600, 750 ));
    rPanel.setPreferredSize( new Dimension( 600, 750 ));
    lPanel.setBackground( Color.darkGray );
    add(lPanel);
    add(rPanel);

    rPanel.setLayout( new GridLayout( 2, 1 ) );
    TowerPanel towerPanel = new TowerPanel();
    JPanel rLowerPanel = new JPanel();
    towerPanel.setPreferredSize( new Dimension( 600, 372 ));
    rLowerPanel.setPreferredSize( new Dimension( 600, 375));
    rPanel.add(towerPanel);
    rPanel.add(rLowerPanel);

    rLowerPanel.setLayout( new FlowLayout() );
    JPanel rLowerSubPanel = new JPanel();
    JPanel mapPanel = new JPanel();
    rLowerSubPanel.setPreferredSize( new Dimension( 299, 370));
    mapPanel.setPreferredSize( new Dimension( 299, 360));
    rLowerSubPanel.setBackground(Color.gray);
    mapPanel.setBackground( Color.lightGray );
    rLowerPanel.add( rLowerSubPanel );
    rLowerPanel.add( mapPanel );

    GameController controller = new GameController();
    towerPanel.addMouseListener(controller);
    towerPanel.addMouseMotionListener(controller);
    towerPanel.addComponentListener(controller);

    GameData.getInstance().setnDisks(4);
    GameData.getInstance().setSize(this.getWidth(), this.getHeight());
    GameData.getInstance().addPropertyChangeListener(towerPanel);
  }

  public static void main(String[] args) {

    GameMain main = new GameMain();
    main.setTitle("Towers of Hanoi");
    main.setSize( main.getLayout().preferredLayoutSize( main ));
    main.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    main.setVisible(true);
  }
}
